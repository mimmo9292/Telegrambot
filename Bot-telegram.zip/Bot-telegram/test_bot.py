import asyncio
from telegram import Bot
from telegram.error import TelegramError
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

async def send_test_message():
    bot = Bot(token=TELEGRAM_BOT_TOKEN)
    try:
        async with bot:
            await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text="🚀 Test del bot - funziona!")
            print("Messaggio inviato con successo!")
    except TelegramError as e:
        print(f"Errore nell'invio del messaggio: {e}")

if __name__ == "__main__":
    asyncio.run(send_test_message())