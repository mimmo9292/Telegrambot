import requests
import time
import os
import random
import json
import locale

def send_message(text):
    token = os.environ.get('TELEGRAM_BOT_TOKEN', '').strip()
    chat_id = os.environ.get('TELEGRAM_CHAT_ID', '').strip()
    
    # Debug: verifica che i valori siano impostati
    if not token:
        print("ERRORE: TELEGRAM_BOT_TOKEN non trovato nelle variabili d'ambiente!")
        return
    if not chat_id:
        print("ERRORE: TELEGRAM_CHAT_ID non trovato nelle variabili d'ambiente!")
        return
        
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML"
    }
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            print("Messaggio inviato con successo!")
        else:
            print(f"Errore nell'invio: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Errore: {e}")

def format_price(price):
    """Formatta il prezzo con virgola per decimali e punto per migliaia (stile italiano)"""
    try:
        # Converte in formato italiano: punto per migliaia, virgola per decimali
        if price >= 1:
            # Per prezzi >= 1, mostra 2 decimali
            formatted = f"{price:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        else:
            # Per prezzi < 1, mostra più decimali per precisione
            formatted = f"{price:,.4f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        return f"${formatted}"
    except:
        return f"${price}"

def get_real_price(symbol):
    """Ottiene il prezzo reale da CoinGecko API"""
    try:
        # Mappa dei simboli CoinGecko
        symbol_map = {
            'BTC/USDT': 'bitcoin',
            'ETH/USDT': 'ethereum',
            'SOL/USDT': 'solana',
            'XRP/USDT': 'ripple',
            'ADA/USDT': 'cardano',
            'DOT/USDT': 'polkadot',
            'AVAX/USDT': 'avalanche-2',
            'LINK/USDT': 'chainlink',
            'UNI/USDT': 'uniswap',
            'ATOM/USDT': 'cosmos',
            'LTC/USDT': 'litecoin',
            'DOGE/USDT': 'dogecoin'
        }
        
        coin_id = symbol_map.get(symbol)
        if not coin_id:
            print(f"Simbolo non supportato: {symbol}")
            return None
        
        # API gratuita di CoinGecko
        url = f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            if coin_id in data and 'usd' in data[coin_id]:
                price = float(data[coin_id]['usd'])
                return round(price, 4)
        
        print(f"Errore API CoinGecko per {symbol}: {response.status_code}")
        return None
        
    except Exception as e:
        print(f"Errore nel recupero prezzo per {symbol}: {e}")
        return None

def generate_trading_signal():
    """Genera un segnale di trading demo con raccomandazioni sulla leva per Bybit"""
    
    # Lista delle coppie più liquide e popolari su Bybit (per volume)
    cryptos = [
        'BTC/USDT',   # #1 per volume
        'ETH/USDT',   # #2 per volume  
        'SOL/USDT',   # #3 per volume
        'XRP/USDT',   # Top volume
        'ADA/USDT',   # Popolare
        'DOT/USDT',   # Alta liquidità
        'AVAX/USDT',  # Popolare
        'LINK/USDT',  # DeFi leader
        'UNI/USDT',   # DEX token
        'ATOM/USDT',  # Cosmos
        'LTC/USDT',   # Storico
        'DOGE/USDT'   # Meme coin
    ]
    
    # Tipi di segnale
    signal_types = ['LONG', 'SHORT']
    
    # Seleziona casualmente
    crypto = random.choice(cryptos)
    signal_type = random.choice(signal_types)
    
    # Ottiene il prezzo reale da Bybit
    entry_price = get_real_price(crypto)
    price_source = "💰 PREZZO REALE"
    if entry_price is None:
        # Fallback a prezzo demo solo se l'API fallisce
        entry_price = round(random.uniform(0.5, 100), 4)
        price_source = "⚠️ DEMO"
        print(f"⚠️ Usando prezzo demo per {crypto}: ${entry_price}")
    else:
        print(f"✅ Prezzo reale ottenuto per {crypto}: ${entry_price}")
    
    # Calcola stop loss e take profit
    if signal_type == 'LONG':
        stop_loss = round(entry_price * 0.97, 4)  # -3%
        tp1 = round(entry_price * 1.02, 4)  # +2%
        tp2 = round(entry_price * 1.04, 4)  # +4%
        tp3 = round(entry_price * 1.06, 4)  # +6%
        leverage_suggestion = random.choice(['3x', '5x', '7x'])
    else:  # SHORT
        stop_loss = round(entry_price * 1.03, 4)  # +3%
        tp1 = round(entry_price * 0.98, 4)  # -2%
        tp2 = round(entry_price * 0.96, 4)  # -4%
        tp3 = round(entry_price * 0.94, 4)  # -6%
        leverage_suggestion = random.choice(['3x', '5x', '7x'])
    
    # Suggerimenti di gestione del rischio
    risk_suggestions = [
        "Usa solo 1-2% del capitale",
        "Considera il DCA se il prezzo va contro",
        "Chiudi parzialmente ai primi TP",
        "Non andare all-in su un singolo trade",
        "Controlla sempre il sentiment di mercato"
    ]
    
    risk_tip = random.choice(risk_suggestions)
    
    message = f"""
🚀 <b>SEGNALE BYBIT</b> 📊

🏢 <b>Exchange:</b> Bybit
💰 <b>Coppia:</b> {crypto}
📈 <b>Direzione:</b> {signal_type}
{price_source} <b>Entry:</b> {format_price(entry_price)}
🛡️ <b>Stop Loss:</b> {format_price(stop_loss)}

🎯 <b>Take Profit:</b>
   TP1: {format_price(tp1)} (25%)
   TP2: {format_price(tp2)} (50%) 
   TP3: {format_price(tp3)} (25%)

⚡ <b>Leva Bybit:</b> {leverage_suggestion}
⚠️ <b>Gestione Rischio:</b> {risk_tip}

⏰ <b>Orario:</b> {time.strftime("%H:%M:%S")}

<i>⚠️ Segnale demo per Bybit. DYOR sempre!</i>
"""
    
    return message

def main():
    print("Bot di trading Bybit avviato - invio messaggio di benvenuto...")
    send_message("🚀 <b>Bot Bybit Trading Attivato!</b>\n\n🏢 Segnali specifici per Bybit\n📊 Ogni 20 minuti\n⚡ Leva e gestione rischio\n💰 Top coppie liquide\n\n⏰ Primo segnale in arrivo...")
    
    while True:
        print("Generazione e invio nuovo segnale di trading...")
        signal_message = generate_trading_signal()
        send_message(signal_message)
        
        print("Prossimo segnale tra 20 minuti...")
        time.sleep(1200)  # 20 minuti = 1200 secondi

if __name__ == "__main__":
    main()