# Overview

This is a cryptocurrency trading bot that provides automated technical analysis signals for the top 250 cryptocurrencies by market cap. The bot integrates with the CoinGecko API to fetch real-time price data and historical market information, performs technical analysis using indicators like EMA (Exponential Moving Average) and RSI (Relative Strength Index), and delivers trading signals via Telegram notifications.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Components

**Data Collection Layer**
- Uses CoinGecko API as the primary data source for cryptocurrency market data
- Fetches top 250 coins by market cap for comprehensive coverage
- Retrieves 30-day historical price data for technical analysis calculations

**Technical Analysis Engine**
- Implements pandas DataFrames for efficient data manipulation and time series analysis
- Uses the `ta` (Technical Analysis) library for indicator calculations
- Calculates short-term (9-period) and long-term (21-period) EMAs for trend analysis
- Implements 14-period RSI for momentum analysis
- Processes price data with proper timestamp handling and data type conversion

**Notification System**
- Telegram Bot API integration for real-time signal delivery
- Asynchronous message handling using Python's asyncio
- Environment variable configuration for secure credential management
- HTML parsing support for formatted messages

**Application Structure**
- `main.py`: Core trading logic and technical analysis functions
- `simple_bot.py`: Simplified bot implementation with real price fetching
- `test_bot.py`: Testing utilities for bot functionality verification
- `config.py`: Configuration management (note: contains hardcoded tokens that should be moved to environment variables)

## Design Patterns

**Modular Architecture**
- Separation of concerns with distinct modules for data fetching, analysis, and notifications
- Function-based approach for easy testing and maintenance

**Error Handling Strategy**
- Try-catch blocks for API call failures and data processing errors
- Graceful degradation when insufficient data is available for analysis

**Data Processing Pipeline**
- Sequential data flow: fetch → process → analyze → notify
- Pandas-based data transformation for efficient numerical operations

# External Dependencies

## APIs and Services
- **CoinGecko API**: Primary cryptocurrency market data provider
  - Market data endpoint for top 250 coins
  - Historical price data with 30-day lookback
  - No authentication required for basic usage

- **Telegram Bot API**: Notification delivery platform
  - Bot token authentication required
  - Chat ID targeting for message delivery
  - HTML message formatting support

## Python Libraries
- **requests**: HTTP client for API communications
- **pandas**: Data manipulation and time series analysis
- **ta**: Technical analysis indicator calculations
- **telegram**: Official Telegram Bot API wrapper
- **asyncio**: Asynchronous programming support for bot operations

## Configuration Management
- Bot credentials currently hardcoded in `config.py`
- Environment variable support implemented in `simple_bot.py`
- Recommended migration to environment variables for security

## Rate Limiting Considerations
- CoinGecko API has rate limits that need to be respected
- Implementation includes basic error handling but may need throttling for production use